# Changelog

## 0.4.0 — 2026-10-15

- Add portable public material configuration, source, status/progress, reader, import/retry and permitted bulk-action contracts for API v1.
- Keep all 0.3.0 auth, school and family exports and clients unchanged. Material file encoding, cookie/session lookup and HTTP transport belong to the host; no provider, runtime grant or database type is exported.
- Analysis readiness stays distinct from lesson/practice artifacts. Processor availability and current school/learner permissions remain server decisions.

## 0.3.0 — 2026-10-15

- Add portable guardian/consent, minimal age/handoff, school guardian, child profile, media and learning policy, and scoped device/PIN contracts through `CoLearnerFamilyClient`.
- Keep account JWT, opaque device and opaque child credentials host-supplied and separate. No client-side permission grant, browser storage, AI provider or database dependency is added.
- Retain auth/health and all 34 school operations. Separate family transports add PUT without widening the original auth transport type. Public API remains v1.

## 0.2.0 — 2026-10-14

- Add portable school identity, workspace, email verification, invitations, membership status, school provisioning, academic years/terms/classes, rosters, teacher assignments and CSV import contracts.
- Add `CoLearnerSchoolClient` with 34 named methods matching the documented server handlers, injected transport/headers, cancellation, encoded identifiers/cursors, existing success-envelope support and runtime domain checks.
- Keep `CoLearnerClient`, auth/health contracts, `Transport`/`TransportRequest`, typed error class and canonical URL behavior compatible. Auth transports retain their existing GET/POST surface; school transports add PATCH/DELETE through separate types.
- Package minor version 0.2.0 is independent of API major v1; no `/api/v2`, provider runtime, web-framework import or database import.

## 0.1.0 — 2026-10-14

- Initial portable v1 auth/health contracts, injected transport, success validation and typed errors.
