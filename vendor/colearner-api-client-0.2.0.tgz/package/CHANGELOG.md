# Changelog

## 0.2.0 — 2026-10-14

- Add portable school identity, workspace, email verification, invitations, membership status, school provisioning, academic years/terms/classes, rosters, teacher assignments and CSV import contracts.
- Add `CoLearnerSchoolClient` with 34 named methods matching the documented server handlers, injected transport/headers, cancellation, encoded identifiers/cursors, existing success-envelope support and runtime domain checks.
- Keep `CoLearnerClient`, auth/health contracts, `Transport`/`TransportRequest`, typed error class and canonical URL behavior compatible. Auth transports retain their existing GET/POST surface; school transports add PATCH/DELETE through separate types.
- Package minor version 0.2.0 is independent of API major v1; no `/api/v2`, provider runtime, web-framework import or database import.

## 0.1.0 — 2026-10-14

- Initial portable v1 auth/health contracts, injected transport, success validation and typed errors.
