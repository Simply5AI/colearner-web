# CoLearner portable client

Version 0.2.0 includes public auth/health and school contracts, runtime response checks and injected transports. It imports no Next.js, Auth.js, database or provider SDK. A future native adapter can supply its supported fetch and credential store; streaming is outside this slice.

```ts
const client = new CoLearnerClient({ baseUrl: 'https://api.example.test', transport: fetch });
await client.login({ email: 'user@example.test', password: suppliedPassword });

const schools = new CoLearnerSchoolClient({
  baseUrl: 'https://api.example.test',
  transport: fetch,
  getHeaders: () => ({ Authorization: `Bearer ${suppliedAccessToken}` }),
});
const memberships = await schools.workspaces();
const selected = await schools.selectWorkspace(memberships.items[0].membershipId);
const classes = await schools.classes(selected.schoolId, { page: 1, pageSize: 25 });
```

Build with the workspace TypeScript compiler, then package with `npm pack --ignore-scripts`. The web repository consumes a checked-in release tarball under `vendor/` so it builds without a sibling checkout. When registry publishing is authorised, switch to the same package/version from the registry. Do not use cross-checkout source imports.

The current interfaces are a reviewed bounded contract, checked against exported OpenAPI fixtures. Full automated OpenAPI type generation and coverage of the remaining API domains belong to later batches. API major v1 and package version 0.2.0 have independent lifecycles.

`CoLearnerSchoolClient` exposes 34 named operations covering profile/workspaces/selection; account email verification; school invitations and memberships; years, terms, classes; manual roster enrollment/archive/transfer and non-mutating promotion preview; teacher assignments/revocation and own assignment list; CSV preview/idempotent commit; and step-up-protected platform provisioning/admin grant/status. See the server's `docs/b02-academics.md` and school-identity OpenAPI export for handler coverage. The client never grants a role or verifies consent itself. Platform operations require the existing server-admin session and fresh reauthentication; an injected adapter supplies those credentials without changing global learner roles.

The original `TransportRequest` remains GET/POST for source compatibility. `SchoolTransportRequest` separately supports GET/POST/PATCH/DELETE. Both use the existing `TransportResponse`; optional signals and asynchronous `getHeaders` work on web and native transports. Browser cookies/credentials, secure storage and bearer acquisition belong to the host adapter. No built-in token persistence, framework session lookup, school authority or provider call is included.

Responses use the existing `{statusCode,data,timestamp}` envelope; compatible bare payloads are supported by transport adapters. Runtime checks reject invalid role/status/board/grade discriminants, misleading guardian access, unclaimed identity mismatches, inconsistent pagination and CSV totals, and malformed promotion/receipt states. Returned objects may retain compatible additional fields. Network/header and invalid-JSON failures become typed safe errors; caller-aborted requests retain the transport abort. IDs and cursors are encoded, dot-only path segments are rejected, and invitation/verification evidence appears only in request bodies.

The school-client regression suite uses the built package artifact in `apps/api/src/modules/school-academics/school-client.spec.ts` with the existing Jest runner, so run the package build first. It covers all named method/handler/body mappings, runtime hostile responses, transport/abort/error normalization and the original auth/health exports. Package build/typecheck uses the workspace's installed TypeScript compiler. There are no new dependencies or publishing steps in this release.
