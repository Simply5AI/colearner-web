# CoLearner portable client

The initial auth/health slice includes public contracts, runtime response checks and an injected transport. It imports no Next.js, Auth.js, database or provider SDK. A future native adapter can supply its supported fetch and credential store; streaming is outside this slice.

```ts
const client = new CoLearnerClient({ baseUrl: 'https://api.example.test', transport: fetch });
await client.login({ email: 'user@example.test', password: suppliedPassword });
```

Build with the workspace TypeScript compiler, then package with `npm pack --ignore-scripts`. The web repository consumes a checked-in release tarball under `vendor/` so it builds without a sibling checkout. When registry publishing is authorised, switch to the same package/version from the registry. Do not use cross-checkout source imports.

The current interfaces are a reviewed bounded contract, checked against exported OpenAPI fixtures. Full automated OpenAPI type generation and coverage of the remaining API domains belong to later batches. API major v1 and package version 0.1.0 have independent lifecycles.
