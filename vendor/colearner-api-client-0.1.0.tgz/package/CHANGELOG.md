# Changelog

## 0.1.0 — 2026-10-14

- Initial portable v1 auth/health contracts, injected transport, success validation and typed errors.
